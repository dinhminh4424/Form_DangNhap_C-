﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace WindowsFormsApp1
{
    public partial class DangKi : Form
    {
        string path = @"Data Source=LAPTOP-P4UFGHKF\SQLEXPRESS;Initial Catalog=TaiKhoanNguoiDung;Integrated Security=True;TrustServerCertificate=True";
        public DangKi()
        {
            InitializeComponent();
        }

        private void DangKi_Load(object sender, EventArgs e)
        {

        }


// -------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------


        private string BamMa(string x)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] mkByte = sha.ComputeHash(Encoding.UTF8.GetBytes(x));
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < mkByte.Length; i++)
                {
                    sb.Append(mkByte[i].ToString("x2"));
                }
                return sb.ToString();
            }
        }            

        private void btn_DK_Click(object sender, EventArgs e)
        {
            string us = txt_US.Text;
            string pw = txt_PW.Text;

            pw = BamMa(pw);
            string ten = txt_Ten.Text;
            string sdt = txt_SDT.Text;


            try
            {
                SqlConnection conn = new SqlConnection(path);
                conn.Open();

                SqlCommand cm = new SqlCommand();
                cm.CommandType = CommandType.Text;
                cm.CommandText = "insert into DangNhap (TaiKhoan, MatKhau, Ten, SDT, Quyen) values ('" + us + "', '" + pw + "', '" + ten+ "', '" + sdt + "', 'user')";

                cm.Connection = conn;
                int kq= cm.ExecuteNonQuery();
                if(kq > 0)
                {
                    MessageBox.Show("ĐÃ TẠO TÀI KHOẢN THÀNH CÔNG");
                }
                else
                {
                    MessageBox.Show("TẠO TÀI KHOẢN THẤT BẠI");
                }


            }
            catch (Exception ex)
            {
            }

        }

        private void btn_DN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txt_PW_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}

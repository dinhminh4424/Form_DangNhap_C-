﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
               
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pic_tk = new System.Windows.Forms.PictureBox();
            this.btn_ChucNangAdmin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.list_DS = new System.Windows.Forms.ListView();
            this.cln_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cln_PW = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cln_ten = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cln_SDT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_DK = new System.Windows.Forms.Button();
            this.btn_DN = new System.Windows.Forms.Button();
            this.txt_PW = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_US = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cHỨCNĂNGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mn_chucnang = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngKíToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemThôngTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_tk)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pic_tk);
            this.panel1.Controls.Add(this.btn_ChucNangAdmin);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.list_DS);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1048, 549);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pic_tk
            // 
            this.pic_tk.Image = ((System.Drawing.Image)(resources.GetObject("pic_tk.Image")));
            this.pic_tk.Location = new System.Drawing.Point(999, 74);
            this.pic_tk.Name = "pic_tk";
            this.pic_tk.Size = new System.Drawing.Size(37, 35);
            this.pic_tk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_tk.TabIndex = 7;
            this.pic_tk.TabStop = false;
            this.pic_tk.Click += new System.EventHandler(this.pic_tk_Click);
            // 
            // btn_ChucNangAdmin
            // 
            this.btn_ChucNangAdmin.Location = new System.Drawing.Point(38, 427);
            this.btn_ChucNangAdmin.Name = "btn_ChucNangAdmin";
            this.btn_ChucNangAdmin.Size = new System.Drawing.Size(200, 42);
            this.btn_ChucNangAdmin.TabIndex = 5;
            this.btn_ChucNangAdmin.Text = "Chức Năng Admin";
            this.btn_ChucNangAdmin.UseVisualStyleBackColor = true;
            this.btn_ChucNangAdmin.Click += new System.EventHandler(this.btn_ChucNangAdmin_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(226, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(613, 43);
            this.label1.TabIndex = 2;
            this.label1.Text = "ĐĂNG NHẬP TÀI KHOẢN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // list_DS
            // 
            this.list_DS.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.cln_ID,
            this.cln_PW,
            this.cln_ten,
            this.cln_SDT});
            this.list_DS.FullRowSelect = true;
            this.list_DS.GridLines = true;
            this.list_DS.HideSelection = false;
            this.list_DS.Location = new System.Drawing.Point(360, 115);
            this.list_DS.Name = "list_DS";
            this.list_DS.Size = new System.Drawing.Size(685, 378);
            this.list_DS.TabIndex = 1;
            this.list_DS.UseCompatibleStateImageBehavior = false;
            this.list_DS.View = System.Windows.Forms.View.Details;
            this.list_DS.SelectedIndexChanged += new System.EventHandler(this.list_DS_SelectedIndexChanged);
            // 
            // cln_ID
            // 
            this.cln_ID.Text = "Tài khoản";
            this.cln_ID.Width = 125;
            // 
            // cln_PW
            // 
            this.cln_PW.Text = "Mật Khẩu";
            this.cln_PW.Width = 134;
            // 
            // cln_ten
            // 
            this.cln_ten.Text = "Tên Người Dùng";
            this.cln_ten.Width = 156;
            // 
            // cln_SDT
            // 
            this.cln_SDT.Text = "SDT";
            this.cln_SDT.Width = 91;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_DK);
            this.groupBox1.Controls.Add(this.btn_DN);
            this.groupBox1.Controls.Add(this.txt_PW);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_US);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(32, 115);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(322, 306);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông Tin";
            // 
            // btn_DK
            // 
            this.btn_DK.Location = new System.Drawing.Point(160, 207);
            this.btn_DK.Name = "btn_DK";
            this.btn_DK.Size = new System.Drawing.Size(148, 37);
            this.btn_DK.TabIndex = 5;
            this.btn_DK.Text = "ĐĂNG KÍ";
            this.btn_DK.UseVisualStyleBackColor = true;
            this.btn_DK.Click += new System.EventHandler(this.btn_DK_Click);
            // 
            // btn_DN
            // 
            this.btn_DN.Location = new System.Drawing.Point(10, 207);
            this.btn_DN.Name = "btn_DN";
            this.btn_DN.Size = new System.Drawing.Size(144, 37);
            this.btn_DN.TabIndex = 4;
            this.btn_DN.Text = "ĐĂNG NHẬP";
            this.btn_DN.UseVisualStyleBackColor = true;
            this.btn_DN.Click += new System.EventHandler(this.btn_DN_Click);
            // 
            // txt_PW
            // 
            this.txt_PW.Location = new System.Drawing.Point(6, 152);
            this.txt_PW.Name = "txt_PW";
            this.txt_PW.Size = new System.Drawing.Size(302, 27);
            this.txt_PW.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(6, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mật Khẩu:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_US
            // 
            this.txt_US.Location = new System.Drawing.Point(6, 84);
            this.txt_US.Name = "txt_US";
            this.txt_US.Size = new System.Drawing.Size(302, 27);
            this.txt_US.TabIndex = 1;
            this.txt_US.TextChanged += new System.EventHandler(this.txt_US_TextChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tài Khoản:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cHỨCNĂNGToolStripMenuItem,
            this.xemThôngTinToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1048, 28);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cHỨCNĂNGToolStripMenuItem
            // 
            this.cHỨCNĂNGToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mn_chucnang,
            this.đăngKíToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.cHỨCNĂNGToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cHỨCNĂNGToolStripMenuItem.Image")));
            this.cHỨCNĂNGToolStripMenuItem.Name = "cHỨCNĂNGToolStripMenuItem";
            this.cHỨCNĂNGToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.cHỨCNĂNGToolStripMenuItem.Text = "CHỨC NĂNG";
            // 
            // mn_chucnang
            // 
            this.mn_chucnang.Image = ((System.Drawing.Image)(resources.GetObject("mn_chucnang.Image")));
            this.mn_chucnang.Name = "mn_chucnang";
            this.mn_chucnang.Size = new System.Drawing.Size(213, 26);
            this.mn_chucnang.Text = "Chức Năng Admin";
            this.mn_chucnang.Click += new System.EventHandler(this.btn_ChucNangAdmin_Click);
            // 
            // đăngKíToolStripMenuItem
            // 
            this.đăngKíToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("đăngKíToolStripMenuItem.Image")));
            this.đăngKíToolStripMenuItem.Name = "đăngKíToolStripMenuItem";
            this.đăngKíToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.đăngKíToolStripMenuItem.Text = "Đăng Kí";
            this.đăngKíToolStripMenuItem.Click += new System.EventHandler(this.btn_DK_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("thoátToolStripMenuItem.Image")));
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.button1_Click);
            // 
            // xemThôngTinToolStripMenuItem
            // 
            this.xemThôngTinToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("xemThôngTinToolStripMenuItem.Image")));
            this.xemThôngTinToolStripMenuItem.Name = "xemThôngTinToolStripMenuItem";
            this.xemThôngTinToolStripMenuItem.Size = new System.Drawing.Size(143, 24);
            this.xemThôngTinToolStripMenuItem.Text = "Xem Thông Tin";
            this.xemThôngTinToolStripMenuItem.Click += new System.EventHandler(this.btn_xemthongtin_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1048, 549);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.Name = "Form1";
            this.Text = "ĐĂNG NHẬP TÀI KHOẢN";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_tk)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_PW;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_US;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView list_DS;
        private System.Windows.Forms.ColumnHeader cln_ID;
        private System.Windows.Forms.ColumnHeader cln_PW;
        private System.Windows.Forms.Button btn_DK;
        private System.Windows.Forms.Button btn_DN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader cln_ten;
        private System.Windows.Forms.ColumnHeader cln_SDT;
        private System.Windows.Forms.Button btn_ChucNangAdmin;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cHỨCNĂNGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mn_chucnang;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngKíToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemThôngTinToolStripMenuItem;
        private System.Windows.Forms.PictureBox pic_tk;
    }
}


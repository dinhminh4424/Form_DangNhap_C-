﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Common;
using System.IO;
using Serilog;


using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            Log.Logger = new LoggerConfiguration()
               .WriteTo.Console() // Ghi log ra console
               .WriteTo.File(@"E:\USER\Documents\DoAn_BMTT\fileLog.txt", rollingInterval: RollingInterval.Day) // Ghi log ra file với đường dẫn chỉ định
               .CreateLogger();

            Log.Information("Ứng dụng đã khởi động TẠI THỜI GIAN {0}", DateTime.Now);
        }

        bool kt = false;

        string path = @"Data Source=LAPTOP-P4UFGHKF\SQLEXPRESS;Initial Catalog=TaiKhoanNguoiDung;Integrated Security=True;Trust Server Certificate=True";

        public  string MaHoaChuoi(string plainText, byte[] key, byte[] iv)
        {
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(plainBytes, 0, plainBytes.Length);
                        cryptoStream.FlushFinalBlock();
                    }

                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        public  string GiaiMaChuoi(string encryptedText, byte[] key, byte[] iv)
        {
            byte[] encryptedBytes = Convert.FromBase64String(encryptedText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cryptoStream.Write(encryptedBytes, 0, encryptedBytes.Length);
                        cryptoStream.FlushFinalBlock();
                    }

                    return Encoding.UTF8.GetString(ms.ToArray());
                }
            }
        }
        public byte[] BamTuChuoi(string s, int keySize)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedPassword = sha256.ComputeHash(Encoding.UTF8.GetBytes(s));

                // Cắt khóa theo kích thước yêu cầu (AES-128: 16 byte, AES-192: 24 byte, AES -256: 32 byte)
                byte[] key = new byte[keySize];
                Array.Copy(hashedPassword, key, keySize);
                return key;
            }
        }

        private void btn_xemthongtin_Click(object sender, EventArgs e)
        {
            if(kt == true)
            {
                string us = txt_US.Text;
                string pw = txt_PW.Text;

                byte[] veter = BamTuChuoi(us, 16);
                byte[] key = BamTuChuoi(pw, 32);
                
                if (list_DS.SelectedItems.Count > -1)
                {
                    ListViewItem lvi = list_DS.SelectedItems[0];
                    string tk = lvi.SubItems[0].Text;
                    string mk = lvi.SubItems[1].Text;
                    string ten = lvi.SubItems[2].Text; 
                    string sdt = lvi.SubItems[3].Text;
                    
                    tk = GiaiMaChuoi(tk, key, veter);
                    string tenGM = GiaiMaChuoi(ten, key, veter);
                    string sdtGM = GiaiMaChuoi(sdt, key, veter);

                    pw = BamMa(pw);
                    if((pw == mk ) && (us == tk))
                    {
                        string nd = "- TÀI KHOẢN: " + us + "\n - MK: " + mk + "\n - TÊN: " + tenGM + "\n - SDT: " + sdtGM;
                        MessageBox.Show(nd, "THÔNG TIN NGƯỜI DÙNG");
                        Log.Information("TÀI KHOẢN {0} XEM THÔNG TIN THÀNH CÔNG \n", us);
                    }
                    else
                    {
                        MessageBox.Show("TÀI KHOẢN {0} XEM THÔNG TIN THẤT BẠI", us);
                        Log.Information("TÀI KHOẢN {0} XEM THÔNG TIN THẤT BẠI TẠI THỜI GIAN {0}\n",us , DateTime.Now);
                    }
                }
            }
            else
            {
                MessageBox.Show("CẦN PHẢI ĐĂNG NHẬP");
            }

        }

// -------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------





        private void btn_DK_Click(object sender, EventArgs e)
        {
            DangKi f = new DangKi();
            f.Show();

        }

        private string BamMa(string ma)
        {
            using(SHA256 sha =  SHA256.Create() )
            {
                byte[] bam = sha.ComputeHash(Encoding.UTF8.GetBytes(ma));
                StringBuilder sb = new StringBuilder();
                for(int i=0; i<bam.Length; i++)
                {
                    sb.Append(bam[i].ToString("x2"));
                }
                return sb.ToString();

            }
        }

        
        private void btn_DN_Click(object sender, EventArgs e)
        {
            string us = txt_US.Text;
            string pw = txt_PW.Text;

            string ma = BamMa(pw); // 2


            byte[] veter = BamTuChuoi(us, 16);             // 4
            byte[] key = BamTuChuoi(pw, 32);               // 4

            string us1 = MaHoaChuoi(us, key, veter);       // 4


            list_DS.Items.Clear();

            try
            {
                SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-P4UFGHKF\SQLEXPRESS;Initial Catalog=TaiKhoanNguoiDung;Integrated Security=True;TrustServerCertificate=True");
                conn.Open();

                SqlCommand cm = new SqlCommand();
                cm.CommandType = CommandType.Text;
                //cm.CommandText = "SELECT * " +
                //                 "FROM DangNhap d " +
                //                 "WHERE d.TaiKhoan = '" + us + "' and d.MatKhau = '" + ma  + "'"; // 1


                cm.CommandText = "SELECT * " + // 3 
                                 "FROM DangNhap d " +//3
                                 "WHERE d.TaiKhoan = @User and d.MatKhau = @Pass";//3

                cm.Parameters.Add("@User", SqlDbType.NVarChar).Value = us; //3
                cm.Parameters.Add("@Pass", SqlDbType.NVarChar).Value = ma; //3

                cm.Connection = conn;

                SqlDataReader r = cm.ExecuteReader();
                int d = 0;
                while (r.Read())
                {
                    Log.Information("Người dùng {0} đã đăng nhập thành công \n",us );

                    MessageBox.Show(" ĐÃ ĐĂNG NHẬP THÀNH CÔNG");
                    d++;
                    string tk = r.GetString(0);
                    string mk = r.GetString(1);
                    string ten = r.GetString(2);
                    string sdt = r.GetString(3);

                    tk = MaHoaChuoi(tk, key, veter); // 4
                    ten = MaHoaChuoi(ten, key, veter); // 4
                    sdt = MaHoaChuoi(sdt, key, veter); // 4

                    ListViewItem lvi = new ListViewItem(tk);
                    lvi.SubItems.Add(mk);
                    lvi.SubItems.Add(ten);
                    lvi.SubItems.Add(sdt);

                    list_DS.Items.Add(lvi); 

                    string quyen = r.GetString(4);
                    if(quyen == "ADMIN")
                    {
                        btn_ChucNangAdmin.Visible = true;
                        mn_chucnang.Visible = true;
                    }

                    kt = true;
                    
                    
                }
                if (d == 0)
                {
                    MessageBox.Show(" ĐĂNG NHẬP THẤT BẠI");
                    Log.Information("ĐANG NHẬP THẤT BẠI \n");
                    kt = false;

                }
                if(kt==true)
                {
                    pic_tk.Visible = true;
                }
                else
                {
                    pic_tk.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Console.WriteLine(ex.Message);
            }
            
        }

        private void txt_US_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Log.Information("ỨNG DỤNG ĐANG ĐÓNG \n");
            Log.CloseAndFlush();
        }

        private void btn_ChucNangAdmin_Click(object sender, EventArgs e)
        {
            ChucNangAdmin f = new ChucNangAdmin(txt_US.Text);
            f.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn_ChucNangAdmin.Visible=false;
            mn_chucnang.Visible=false;
            kt = false;
            pic_tk.Visible=false;
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void list_DS_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pic_tk_Click(object sender, EventArgs e)
        {
           

        }

        private void label1_Click(object sender, EventArgs e)
        {
            list_DS.Items.Clear();
        }
    }
}

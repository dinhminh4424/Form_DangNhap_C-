﻿using Serilog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{


    public partial class ChucNangAdmin : Form
    {
        string x;

        private string BamMa(string x)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] mkByte = sha.ComputeHash(Encoding.UTF8.GetBytes(x));
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < mkByte.Length; i++)
                {
                    sb.Append(mkByte[i].ToString("x2"));
                }
                return sb.ToString();
            }
        }

        string path = @"Data Source=LAPTOP-P4UFGHKF\SQLEXPRESS;Initial Catalog=TaiKhoanNguoiDung;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        public ChucNangAdmin(string x)
        {
            this.x = x;
            InitializeComponent();
            Log.Logger = new LoggerConfiguration()
               .WriteTo.Console() // Ghi log ra console
               .WriteTo.File(@"E:\USER\Documents\DoAn_BMTT\fileLog.txt", rollingInterval: RollingInterval.Day) // Ghi log ra file với đường dẫn chỉ định
               .CreateLogger();

            Log.Information("TÀI KHOẢN {0} ĐÃ MỞ TẠI THỜI GIAN {1}",x, DateTime.Now);
        }

        private void ChucNangAdmin_Load(object sender, EventArgs e)
        {
            upload();
        }

        private void upload()
        {
            list_DS.Items.Clear();
            try
            {
                SqlConnection con = new SqlConnection(path);
                con.Open();
                SqlCommand cm = new SqlCommand();
                cm.CommandType = CommandType.Text;
                cm.CommandText = "SELECT * " +
                                  "FROM DangNhap " +
                                  "WHERE Quyen = 'user'";
                cm.Connection = con;
                SqlDataReader r = cm.ExecuteReader();
                while(r.Read())
                {
                    string id = r.GetString(0);
                    string mk = r.GetString(1);
                    string ten = r.GetString(2);
                    string sdt = r.GetString(3);

                    ListViewItem lvi = new ListViewItem(id);
                    lvi.SubItems.Add(mk);
                    lvi.SubItems.Add(ten);
                    lvi.SubItems.Add(sdt);

                    list_DS.Items.Add(lvi);

                    Console.WriteLine(" CÁI GÌ ĐÓ");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Console.WriteLine(ex.Message);
            }
        }

        private void btn_SuaTT_Click(object sender, EventArgs e)
        {
            try
            {

                String id = txt_us.Text;
                SqlConnection con = new SqlConnection(path);
                con.Open();
                SqlCommand cm = new SqlCommand();
                cm.CommandType = CommandType.Text;
                cm.CommandText =    "UPDATE DangNhap " +
                                    "SET Ten = '"+ txt_Ten.Text +"', SDT = '"+ txt_sdt.Text + "', MatKhau = '"+BamMa(txt_pw.Text) +"' "+
                                    "WHERE TaiKhoan = '"+ id +"'";

                cm.Connection = con;
                int kt = cm.ExecuteNonQuery();
                if (kt > 0)
                {
                    MessageBox.Show("ĐÃ CHỈNH SỬA THÀNH CÔNG");
                    upload();
                    Log.Information("TÀI KHOẢN {0} ĐÃ SỬA THÔNG TIN TÀI KHOẢN {1} TẠI THỜI GIAN {2}", x,id, DateTime.Now);
                }
                else
                {
                    MessageBox.Show("CHỈNH SỬA THẤT BẠI");
                    upload();
                    Log.Information("TÀI KHOẢN {0} ĐÃ SỬA THÔNG TIN TÀI KHOẢN THẤT BẠI {1} TẠI THỜI GIAN {2}", x, id, DateTime.Now);
                }

                upload();

            }
            catch (Exception ex)
            {
                MessageBox.Show("LỖI XÓA: " + ex.Message);
                Console.WriteLine(ex.Message);
            }
        }

        private void list_DS_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(list_DS.SelectedItems.Count > 0)
            {
                ListViewItem lvi = list_DS.SelectedItems[0];
                txt_us.Text = lvi.SubItems[0].Text;
                txt_pw.Text = lvi.SubItems[1].Text;
                txt_Ten.Text = lvi.SubItems[2].Text;
                txt_sdt.Text = lvi.SubItems[3].Text;
                Console.WriteLine(" 123456789");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String ma = txt_us.Text;
            try
            {

               
                SqlConnection con = new SqlConnection(path);
                con.Open();
                SqlCommand cm = new SqlCommand();
                cm.CommandType = CommandType.Text;
                cm.CommandText = "DELETE FROM DangNhap " +
                                    "WHERE TaiKhoan = '" +ma+"'";

                cm.Connection = con;
                int kt = cm.ExecuteNonQuery();
                if (kt > 0)
                {
                    MessageBox.Show("ĐÃ XÓA THÀNH CÔNG");
                    upload();
                    upload();
                    Log.Information("TÀI KHOẢN {0} ĐÃ XÓA THÔNG TIN TÀI KHOẢN {1} TẠI THỜI GIAN {2}", x, ma, DateTime.Now);
                }
                else
                {
                    MessageBox.Show("XÓA THẤT BẠI");
                    upload();
                    Log.Information("TÀI KHOẢN {0} XÓA THÔNG TIN TÀI KHOẢN THẤT BẠI {1} TẠI THỜI GIAN {2}", x, ma, DateTime.Now);
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("LỖI XÓA: "+ex.Message);
                Console.WriteLine(ex.Message);
            }
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
    }
}
